const CACHE = "xhus-v3";
const ASSETS = ["/", "/index.html"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
});

self.addEventListener("fetch", e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});

self.addEventListener("push", e => {
  const data = e.data ? e.data.json() : { title:"Contabilidad Xhus", body:"Tienes un depósito próximo a vencer" };
  e.waitUntil(self.registration.showNotification(data.title, {
    body: data.body,
    icon: "/favicon.svg",
    badge: "/favicon.svg",
  }));
});
